import React from 'react';
function Dashboard() {
    return (
        <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
            <h1>Richmond Hill Auto OS</h1>
            <ul>
                <li>✔ Work Order Management</li>
                <li>✔ Invoicing & HST</li>
                <li>✔ Technician Tracking</li>
                <li>✔ Boss Board Dashboard</li>
                <li>✔ Paystub Generator</li>
                <li>✔ OCR Tools (VIN, Receipts)</li>
            </ul>
        </div>
    );
}
export default Dashboard;